module.exports = () => {
    return __dirname
}