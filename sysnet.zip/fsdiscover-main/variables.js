module.exports = {
    outputfile: 'paths.txt',
    tempdir:'temp'
}