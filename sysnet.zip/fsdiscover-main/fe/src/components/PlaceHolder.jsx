import React from 'react'

const PlaceHolder = () => {
    return (
        <div className='rounded w-100 active h-100'>
            bg-
        </div>
    )
}

export default PlaceHolder